//
//  SecondViewController.swift
//  test
//
//  Created by Bandish on 17/09/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit

typealias CallBackClosure = ((Bool)->Int)

class SecondViewController: UIViewController {

    var objViewcontroller: ViewController?
    var didBackButtonPressed: CallBackClosure?
    


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
            self?.updateView()
        }
    }
    
    deinit {
        print("secondview controller deinit")
    }
    
    private func updateView() {}
    
    @IBAction func btnBackPressed (sender: UIButton){
        self.navigationController?.popViewController(animated: true)
        if self.didBackButtonPressed != nil{
            print(self.didBackButtonPressed!(true))
        }
    }
    
    
}
