//
//  myView.swift
//  test
//
//  Created by Bandish on 17/06/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit


@IBDesignable
open class myView: UIView {
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    class func nibSetup(x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat) -> myView {
        let xibView = Bundle.main.loadNibNamed("myView", owner: self, options: nil)?[0] as! myView
        xibView.frame = CGRect(x: x, y: y, width: width, height: height)
        return xibView
    }
    
    open override func draw(_ rect: CGRect) {
        super.draw(rect)
//        guard let context = UIGraphicsGetCurrentContext() else { return }
//        context.setFillColor(UIColor.brown.cgColor)
//        let backgroundPath = UIBezierPath(roundedRect: rect, cornerRadius: 0)
//        backgroundPath.fill()
    }
    
    
    
}
