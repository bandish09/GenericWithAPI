//
//  ViewController.swift
//  test
//
//  Created by Bandish on 24/01/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var customeView : myView!
    let intArray = [1,2,5,9,3,7]
    let strArray = ["bandish","abhi","john"]
    let dictArray = [["name":"botad"],["name":"gateway"],["name":"gandhinagar"]]
    
    let myActivityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)


    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .white
        
        myActivityIndicator.center = view.center
        myActivityIndicator.hidesWhenStopped = true
        myActivityIndicator.stopAnimating()
        view.addSubview(myActivityIndicator)
        
    }
    
    deinit {
        print("viewcontroller deint call")
    }
    
    
    func printArray<T>(arr:[T]){
        arr.map { (element) in
            //Integer Type
            if T.self is Int.Type{
                let mul = element as! Int * 10
                print("mul::: \(mul)")
            }
            
            //String Type
            if T.self is String.Type{
                print("i am \(element)")
            }
            //Dictionary Type
            if T.self is Dictionary<String, String>.Type{
                if let Dict = element as? [String : String]{
                    print("i am from \(String(describing: Dict["name"]))")
                }
            }
        }
    }
    
    public struct Post: Codable {
        let title: String
        let body: String
    }

    public struct Comment: Codable {
        let name: String
        let email: String
        let body: String
    }

//    public func loadResources<T: Decodable>(from path: String,
//                                            completion: ([T]) -> ()) {
//        guard
//            let url = URL(string: path), let data = try? Data(contentsOf: url)
//            else { return }
//
//        let json = try? JSONDecoder().decode([T].self, from: data)
//
//        guard let result = json else { return }
//        completion(result)
//    }

    
    public func loadResources<T: Decodable>(from path: String, completion: @escaping ([T]) -> ()) {
        guard let url = URL(string: path)  else { return }
        let session = URLSession.shared
        session.dataTask(with: url) { data, response, error in
            if error != nil {
                print(error.debugDescription)
            }
            guard let data = data else { return }
            do {
                let result = try JSONDecoder().decode([T].self, from: data)
                completion(result)
            } catch  {
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    public func loadComments(completion: @escaping ([Comment]) -> ()) {
        loadResources(from: "https://jsonplaceholder.typicode.com/posts/1/comments",
                      completion: completion)
    }

    public func loadPosts(completion: @escaping ([Post]) -> Void) {
        
        loadResources(from: "https://jsonplaceholder.typicode.com/posts",
                      completion: completion)
    }
    
    @IBAction func btnNextViewController(_ sender: UIButton){
        self.myActivityIndicator.startAnimating()
        
        loadComments { comments in
            DispatchQueue.main.async {
                self.myActivityIndicator.stopAnimating()
            }
            
            UserDefaults.standard.set(try? PropertyListEncoder().encode(comments), forKey:"comments")
            UserDefaults.standard.synchronize()
            
            if let data = UserDefaults.standard.value(forKey:"comments") as? Data {
                let commentsArr = try? PropertyListDecoder().decode(Array<Comment>.self, from: data)
                for name in commentsArr!{
                    print("name is \(name.name)")
                }
            }
        }
        
        
//        self.printArray(arr: intArray)
//        self.printArray(arr: strArray)
//        self.printArray(arr: dictArray)
        
        
//        let ObjSecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController_SID") as! SecondViewController
//        ObjSecondViewController.didBackButtonPressed = { retVal in
//            print("call back calling...")
//            return 50
//        }
//        self.navigationController?.pushViewController(ObjSecondViewController, animated: true)
        
//        ObjSecondViewController.objViewcontroller = self
//        let nav = UINavigationController(rootViewController: ObjSecondViewController)
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        appDelegate.window?.rootViewController = nav
    }
    
    
    
    @IBAction func btnLoadCustomView(_ sender: UIButton) {
        self.customeView = myView.nibSetup(x: 0.0, y: self.view.bounds.maxY, width: self.view.bounds.width, height: self.view.bounds.height)

        
//        self.customeView = myView(frame: CGRect(x: 0.0, y: self.view.bounds.maxY, width: self.view.bounds.width, height: self.view.bounds.height))
        
        
        
        if self.customeView != nil{
            DispatchQueue.main.async {
                self.view.addSubview(self.customeView)
                
                UIView.animate(withDuration: 0.5, animations: {
                    self.customeView.frame = self.view.bounds
                }, completion: { (Bool) in
                    self.view.isUserInteractionEnabled = true
                })
            }
        }
    }
    
    
    
}

